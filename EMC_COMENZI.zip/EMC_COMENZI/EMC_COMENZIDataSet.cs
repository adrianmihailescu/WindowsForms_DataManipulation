﻿namespace EMC_COMENZI {
    
    
    public partial class EMC_COMENZIDataSet {
    }
}

namespace EMC_COMENZI.EMC_COMENZIDataSetTableAdapters {


    public partial class COMENZITableAdapter
    {
    }
}

namespace EMC_COMENZI.EMC_COMENZIDataSetTableAdapters
{
    
    
    public partial class COMENZI_DETALIUTableAdapter {
    }
}
